﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace EcommerceAPI.Migrations
{
    public partial class intialcreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilde) { }

        protected override void Down(MigrationBuilder migrationBuilder) { }
    }
}
